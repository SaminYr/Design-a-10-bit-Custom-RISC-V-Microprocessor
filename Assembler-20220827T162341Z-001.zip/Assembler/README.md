You must use latest MinGW compiler from ( https://nuwen.net/mingw.html ),
with C++14 or C++11 enabled in compiler settings.

install mingw-1x.x-without-git.exe from the above link.
